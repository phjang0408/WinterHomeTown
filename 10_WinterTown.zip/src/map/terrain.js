// 지형: 땅, 강변 경사, 둔치, 강물, 강 건너편. 높이와 걸을 수 있는 범위를 월드에 등록한다.
import * as THREE from '../lib/three.js';
import { root } from '../core/engine.js';
import { M, G, flat, box } from '../core/gfx.js';
import { sr, PI } from '../core/util.js';
import { W } from '../world/world.js';
import { UNIT as U } from '../config.js';
import { BANK, PLAT, DOCK, SLED, PIT, SCHOOL, WALK, NROAD, BRIDGES, RAILS, SIDING, RSIDE, STATION_X } from './layout.js';
import { PLATFORM, TRACK } from '../props/railway.js';

// 승강장 · 화물 홈 윗면 높이 (양 끝 경사로). 소품(platformModule)과 같은 치수.
function deckY(r, h, ramp){ return (x, z) => { if (x < r.x0 || x > r.x1 || z < r.z0 || z > r.z1) return null;
  const hl = (r.x1 - r.x0) / 2 - ramp * U, d = Math.abs(x - (r.x0 + r.x1) / 2) - hl; return d <= 0 ? h * U : Math.max(0, h * U * (1 - d / (ramp * U))); }; }

export function buildTerrain(){
  // 높이: 승강장 → 화물 홈 → 선로 도상 → 둔치 → 경사 → 평지 (육교 · 상가 테라스 등 소품 높이는 소품이 등록한다)
  W.addHeight(deckY(PLAT, PLATFORM.h, PLATFORM.ramp));
  W.addHeight(deckY(DOCK, 1, 2));
  const bal = TRACK.bTop * U, by = TRACK.bH * U;
  W.addHeight((x, z) => z < 70 && (RAILS.some(c => Math.abs(z - c) < bal) || (x > SIDING.x0 && x < SIDING.x1 && Math.abs(z - SIDING.z) < bal)) ? by : null);
  W.addHeight((x, z) => z >= RSIDE + 5 ? BANK : null);   // 둔치는 평평 (2026-11-17: 썰매 언덕을 얼음 썰매장으로)
  W.addHeight((x, z) => z > RSIDE ? BANK * (z - RSIDE) / 5 : null);
  W.bounds = (x, z, y) => {
    if (x < WALK.x0 || x > WALK.x1 || z < WALK.z0 || z > WALK.zRiver) return false;
    if (z > NROAD.z0 - .4 && z < NROAD.z1 + .4 && !(BRIDGES.some(b => Math.abs(x - b.x) <= 1.6) && y !== undefined && y > 2)) return false;   // 북쪽 도로: 육교 위로만 (다리 밑 땅에서는 막힌다)
    if (z < NROAD.z0 - .4 && (x < STATION_X[0] || x > STATION_X[1])) return false;
    if (x > SCHOOL.x0 + .3 && z > SCHOOL.z0 - .3 && z < SCHOOL.z1 + .3) return false;                  // 학교 (닫음)               // 선로 쪽 자갈밭: SW · ES 보도 선 사이만
    if (z > NROAD.z1 && z < 256 && x < 15.6) return false;                                    // 아파트단지 서쪽 방음벽 바깥
    if (z > NROAD.z1 && z < 95.7 && x < 186) return false;                                    // 아파트단지 북쪽 방음벽 바깥
    return true;
  };

  // 땅 한 장 (낮춘 공원 자리는 비운다)
  [[-800, -800, 1400, PIT.z0], [-800, PIT.z1, 1400, RSIDE], [-800, PIT.z0, PIT.x0, PIT.z1], [PIT.x1, PIT.z0, 1400, PIT.z1]].forEach(r => flat(r[0], r[1], r[2], r[3], G(0xf4f7fa), 0));
  const g = new THREE.BufferGeometry();
  // 사면: 둔치 계단(x 177 · 451) 자리는 비운다 (2026-11-17: 계단 디딤판이 사면 판에 묻혀 안 보이던 것)
  const pos = [], idx = []; [[-800, 177 - 2.4], [177 + 2.4, 451 - 2.4], [451 + 2.4, 1400]].forEach(([a, b], k) => {
    pos.push(a, 0, RSIDE, b, 0, RSIDE, a, BANK, RSIDE + 5, b, BANK, RSIDE + 5); const o = k * 4; idx.push(o, o + 2, o + 1, o + 1, o + 2, o + 3); });
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals();
  const slope = new THREE.Mesh(g, M(0xeef2f1)); slope.receiveShadow = true; root.add(slope);
  flat(-800,RSIDE + 5,1400,342.5,G(0xeef3ef),BANK);
  box(-800,342,1400,342.5,.8,M(0xd2dbe2),BANK - .8);
  const water = flat(-800,342.5,1400,452,0xbcd4e1,BANK - .45);
  water.material = new THREE.MeshPhongMaterial({color:0x86b6d8, specular:0xfff4dc, shininess:70});   // 하늘이 비친 강물, 해 쪽으로 윤슬이 생긴다
  box(-800,451.5,1400,452,1,M(0xd2dbe2),BANK - 1.1);
  flat(-800,452,1400,1400,G(0xf2f6f9),BANK + .1);
  W.mmRect(0,RSIDE,640,342,'#e1e9e3'); W.mmRect(0,342,640,380,'#c2d8e4');

  // 떠다니는 얼음 조각
  const floes = [];
  for (let i = 0; i < 22; i++) { const x = sr(-60, 700), z = sr(348, 445);
    const f = new THREE.Mesh(new THREE.CircleGeometry(1, 7), M(0xf4f8fb)); f.rotation.x = -PI / 2; f.scale.set(sr(1.5, 4.5), sr(1.2, 3), 1);
    f.position.set(x, BANK - .42, z); f.userData.v = sr(.25, .7); f.receiveShadow = true; root.add(f); floes.push(f); }
  W.animated.push({obj:null, update:dt => floes.forEach(f => { f.position.x += f.userData.v * dt; if (f.position.x > 700) f.position.x = -60; })});
}
